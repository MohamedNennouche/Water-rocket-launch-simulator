__author__ = "Mohamed Nennouche"
__copyright__ = "Copyright 20XX, WaterRocketPy Team"
__license__ = "MIT"
__version__ = "0.1.0"
__maintainer__ = "Mohamed Nennouche"
__email__ = "moohaaameed.nennouche@gmail.com"
__status__ = "Production"

from .waterRocket import WaterRocket